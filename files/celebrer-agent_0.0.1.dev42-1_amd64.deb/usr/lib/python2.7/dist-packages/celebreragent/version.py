import pbr.version

version_info = pbr.version.VersionInfo('celebrer-agent')
version_string = version_info.cached_version_string()